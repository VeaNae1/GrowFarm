package com.leaf.lack.net

object ApiConfig {
    // ✅ 여기에 ngrok 주소를 넣으세요
    const val BASE_URL = "https://7f91e5fb4f08.ngrok-free.app"
}
