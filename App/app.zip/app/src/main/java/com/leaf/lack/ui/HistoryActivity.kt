// app/src/main/java/com/leaf/lack/ui/HistoryActivity.kt
package com.leaf.lack.ui

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.leaf.lack.R
import com.leaf.lack.net.ApiConfig
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class HistoryActivity : AppCompatActivity() {

    private lateinit var tvHeader: TextView
    private lateinit var listView: ListView

    // ★ ngrok 주소만 바꿔주세요 (끝에 / 없음)
    private val BASE_URL = "${ApiConfig.BASE_URL}"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        tvHeader = findViewById(R.id.history_text)
        listView = findViewById(R.id.list_history)

        tvHeader.text = "과거 분석 내역이 다음과 같습니다."

        fetchHistory()
    }

    private fun fetchHistory() {
        val req = Request.Builder().url("$BASE_URL/results").build()
        OkHttpClient().newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { tvHeader.text = "서버 연결 실패: ${e.message}" }
            }

            override fun onResponse(call: Call, resp: Response) {
                val body = resp.body?.string()
                if (!resp.isSuccessful || body.isNullOrBlank()) {
                    runOnUiThread { tvHeader.text = "서버 응답 실패: ${resp.code}" }
                    return
                }
                try {
                    val root = JSONObject(body)
                    val arr = root.optJSONArray("results") ?: return

                    val items = ArrayList<String>()
                    val ids = ArrayList<Int>()

                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val id = o.getInt("id")
                        val created = o.getString("created_at")
                        items.add("ID $id · $created")
                        ids.add(id)
                    }

                    runOnUiThread {
                        listView.adapter = ArrayAdapter(
                            this@HistoryActivity,
                            android.R.layout.simple_list_item_1,
                            items
                        )
                        listView.setOnItemClickListener { _, _, pos, _ ->
                            val postId = ids[pos]
                            val it = Intent(this@HistoryActivity, ResultActivity::class.java)
                                .putExtra("base_url", BASE_URL)
                                .putExtra("post_id", postId)
                            startActivity(it)
                        }
                    }
                } catch (t: Throwable) {
                    runOnUiThread { tvHeader.text = "파싱 실패: ${t.localizedMessage}" }
                }
            }
        })
    }
}
