package com.leaf.lack.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.leaf.lack.R
import com.leaf.lack.net.ApiConfig
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File
import java.io.IOException

class ImagePreviewActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var analyzeButton: Button
    private lateinit var retakeText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_image_preview)

        imageView = findViewById(R.id.image_preview)
        analyzeButton = findViewById(R.id.btn_analyze)
        retakeText = findViewById(R.id.tv_retake_photo)

        val uriString = intent.getStringExtra("image_uri")
        val imageUri = uriString?.let { Uri.parse(it) }
        if (imageUri != null) {
            imageView.setImageURI(imageUri)
        } else {
            Toast.makeText(this, "이미지를 불러올 수 없습니다", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        analyzeButton.setOnClickListener {
            Toast.makeText(this, "분석을 시작합니다!", Toast.LENGTH_SHORT).show()
            uploadAndOpenReport(imageUri)
        }

        retakeText.setOnClickListener {
            startActivity(Intent(this, CameraCaptureActivity::class.java))
            finish()
        }
    }

    /**
     * 1) 이미지를 /upload 로 업로드
     * 2) 응답의 data.id(=postId)로 ResultActivity를 base_url+post_id 모드로 실행
     * 3) 만약 id가 비었다면 /results에서 최신 id로 폴백
     */
    private fun uploadAndOpenReport(imageUri: Uri) {
        val client = OkHttpClient()

        // 캐시에 임시 파일 생성 후 Multipart 업로드
        val tempFile = kotlin.runCatching {
            val f = File.createTempFile("upload_", ".jpg", cacheDir)
            contentResolver.openInputStream(imageUri)?.use { input ->
                f.outputStream().use { output -> input.copyTo(output) }
            }
            f
        }.getOrElse {
            runOnUiThread { Toast.makeText(this, "임시 파일 생성 실패: ${it.message}", Toast.LENGTH_SHORT).show() }
            return
        }

        val mediaType = "image/*".toMediaTypeOrNull()
        val fileBody = tempFile.asRequestBody(mediaType)
        val form = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", tempFile.name, fileBody)
            .build()

        val req = Request.Builder()
            .url("${ApiConfig.BASE_URL}/upload")
            .post(form)
            .build()

        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@ImagePreviewActivity, "업로드 실패: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    runOnUiThread {
                        Toast.makeText(this@ImagePreviewActivity, "서버 응답 실패: ${response.code}", Toast.LENGTH_SHORT).show()
                    }
                    return
                }
                try {
                    val root = JSONObject(raw)
                    val data = root.optJSONObject("data")
                    val postId = data?.optInt("id", -1) ?: -1
                    if (postId > 0) {
                        // 정상: 업로드된 그 결과로 이동
                        openResult(postId)
                    } else {
                        // 폴백: 최신 결과로 이동 (업로드 직후이므로 최신이 방금 건일 확률이 큼)
                        openLatestResult()
                    }
                } catch (t: Throwable) {
                    runOnUiThread {
                        Toast.makeText(this@ImagePreviewActivity, "응답 파싱 실패: ${t.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        })
    }

    /** 업로드에서 받은 postId로 결과 화면 열기 (ResultActivity가 /report/{id} 조회) */
    private fun openResult(postId: Int) {
        runOnUiThread {
            val intent = Intent(this@ImagePreviewActivity, ResultActivity::class.java)
                .putExtra("base_url", ApiConfig.BASE_URL)
                .putExtra("post_id", postId)
            startActivity(intent)
            finish()
        }
    }

    /**
     * 폴백: /results -> 가장 최신 id로 이동
     * (서버는 id desc로 내려주도록 구현되어 있음)
     */
    private fun openLatestResult() {
        val client = OkHttpClient()
        val req = Request.Builder()
            .url("${ApiConfig.BASE_URL}/results")
            .build()

        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@ImagePreviewActivity, "최신 결과 조회 실패: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    runOnUiThread {
                        Toast.makeText(this@ImagePreviewActivity, "최신 결과 응답 실패: ${response.code}", Toast.LENGTH_SHORT).show()
                    }
                    return
                }
                try {
                    val root = JSONObject(raw)
                    val arr = root.optJSONArray("results")
                    val first = if (arr != null && arr.length() > 0) arr.getJSONObject(0) else null
                    val postId = first?.optInt("id", -1) ?: -1
                    if (postId > 0) {
                        openResult(postId)
                    } else {
                        runOnUiThread {
                            Toast.makeText(this@ImagePreviewActivity, "이동할 결과를 찾지 못했습니다.", Toast.LENGTH_SHORT).show()
                        }
                    }
                } catch (t: Throwable) {
                    runOnUiThread {
                        Toast.makeText(this@ImagePreviewActivity, "최신 결과 파싱 실패: ${t.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        })
    }
}
