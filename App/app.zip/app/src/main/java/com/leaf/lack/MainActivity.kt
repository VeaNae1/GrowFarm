package com.leaf.lack

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

import com.leaf.lack.ui.CameraCaptureActivity
import com.leaf.lack.ui.ImagePreviewActivity
import com.leaf.lack.ui.HistoryActivity
import com.leaf.lack.ui.GallerySelectActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 버튼 누르면 카메라 화면으로 이동 (예: ImagePreviewActivity)
        val btnCamera = findViewById<Button>(R.id.btn_camera)
        btnCamera.setOnClickListener {
            val intent = Intent(this, CameraCaptureActivity::class.java)
            startActivity(intent)
        }

        // 버튼 누르면 갤러리 화면으로 이동
        val btnGallery = findViewById<Button>(R.id.btn_gallery)
        btnGallery.setOnClickListener {
            val intent = Intent(this, ImagePreviewActivity::class.java)
            startActivity(intent)
        }

        // 과거 분석 보기 화면으로 이동
        val btnHistory = findViewById<Button>(R.id.btn_history)
        btnHistory.setOnClickListener {
            val intent = Intent(this, HistoryActivity::class.java)
            startActivity(intent)
        }

        btnGallery.setOnClickListener {
            val intent = Intent(this, GallerySelectActivity::class.java)
            startActivity(intent)
        }

    }
}