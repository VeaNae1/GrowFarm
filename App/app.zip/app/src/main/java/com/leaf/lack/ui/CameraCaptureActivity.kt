// CameraCaptureActivity.kt
package com.leaf.lack.ui

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.leaf.lack.R
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.io.IOException

class CameraCaptureActivity : AppCompatActivity() {

    private var photoUri: Uri? = null
    private lateinit var imageView: ImageView
    private lateinit var takePhotoBtn: Button
    private lateinit var takePictureLauncher: ActivityResultLauncher<Uri>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_camera_capture)

        imageView = findViewById(R.id.image_preview)
        takePhotoBtn = findViewById(R.id.btn_take_photo)

        // 권한 요청
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 100)
        }

        // 사진 촬영 후 처리
        takePictureLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success && photoUri != null) {
                // ✅ 미리보기 화면으로 안전하게 이동
                val previewIntent = Intent(this@CameraCaptureActivity, ImagePreviewActivity::class.java)
                previewIntent.putExtra("image_uri", photoUri.toString())
                startActivity(previewIntent)

                // ❗ 이 줄은 지연되게 하기 위해 post로 처리 (바로 finish() 하면 문제가 발생할 수 있음)
                imageView.post {
                    finish()
                }
            } else {
                Toast.makeText(this, "사진 촬영 실패", Toast.LENGTH_SHORT).show()
            }
        }


        // 버튼 클릭 시 촬영 시작
        takePhotoBtn.setOnClickListener {
            takePicture()
        }
    }

    // 사진 촬영
    private fun takePicture() {
        val resolver = contentResolver
        val contentValues = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "leaf_sample_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        }

        photoUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
        takePictureLauncher.launch(photoUri)
    }

    // Uri → File 변환
    private fun uriToFile(uri: Uri): File {
        val inputStream = contentResolver.openInputStream(uri)
        val file = File(cacheDir, "captured_image_${System.currentTimeMillis()}.jpg")
        val outputStream = file.outputStream()
        inputStream?.copyTo(outputStream)
        inputStream?.close()
        outputStream.close()
        return file
    }

    // 서버 전송 (필요 시 호출)
    private fun uploadImageToServer(file: File) {
        val client = OkHttpClient()

        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart(
                "image",
                file.name,
                file.asRequestBody("image/jpeg".toMediaTypeOrNull())
            )
            .build()

        val request = Request.Builder()
            .url("https://your-server.com/upload") // 🔁 실제 서버 주소로 변경 필요
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("Upload", "실패: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    Log.d("Upload", "성공: ${response.body?.string()}")
                } else {
                    Log.e("Upload", "서버 오류: ${response.code}")
                }
            }
        })
    }
}
